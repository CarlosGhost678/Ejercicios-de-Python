frase = input("Introduce una frase")
vocal = input("Introduce una vocal en minuscula")

print(frase.replace(vocal, vocal.upper()))