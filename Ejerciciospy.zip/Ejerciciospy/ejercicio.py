nombre = input("Ingresar nombre")
numero = int(input("Ingresar numero entero"))

print((nombre+ "\n")* numero)