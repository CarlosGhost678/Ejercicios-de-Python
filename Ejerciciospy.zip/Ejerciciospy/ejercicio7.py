correo = input("Introducir correo electronico")

print(correo[:correo.find("@")] + "@ceu.es")