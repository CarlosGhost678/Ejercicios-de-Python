nombre = input("Ingresar tu nombre completo: ")

print(nombre.lower())
print(nombre.upper())
print(nombre.title())