nombre = input("Introducir nombre completo")

print(nombre.upper)
numero_letras = len(nombre.replace(" ", ""))

print(f"{nombre} tiene {numero_letras} letras")