frase = input("Introduce una frase")

frase_invertida = frase[::-1]

print("frase invertida:", frase_invertida)