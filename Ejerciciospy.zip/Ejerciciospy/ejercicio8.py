def main():
    # Pedir al usuario que introduzca el precio en euros con dos decimales
    precio = input("Introduce el precio del producto en euros (con dos decimales): ")
    
    try:
        # Convertir el precio a un número decimal
        precio_decimal = float(precio)
        
        # Separar euros y céntimos
        euros = int(precio_decimal)  # Parte entera del precio
        centimos = int(round((precio_decimal - euros) * 100))  # Parte decimal, convertido a céntimos
        
        # Mostrar el resultado
        print(f"Número de euros: {euros}")
        print(f"Número de céntimos: {centimos}")
        
    except ValueError:
        print("El precio introducido no es válido. Por favor, introduce un número con dos decimales.")

if __name__ == "__main__":
    main()
