def main():
    
    productos_input = input("Introduce los productos de la cesta, separados por comas: ")
    
    
    productos = productos_input.split(',')
    
    
    productos = [producto.strip() for producto in productos]
    
    
    print("Productos en la cesta:")
    for producto in productos:
        print(producto)

if __name__ == "__main__":
    main()
